//
//
//
//
//

public class EmployeeTest {

	public static void main (String [] args) {

		Employee employee = new Employee();

		employee.input();

		employee.display();
		
	}
}
